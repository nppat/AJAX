Create a weather app

1) Use the http://openweathermap.org/api API
2) Make form on index.html for city input
3) On form submit, add city to API query in jquery_functions
4) Return data onto index.html