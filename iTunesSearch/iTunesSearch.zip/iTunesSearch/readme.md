**For some odd reason, I get a 400 error almost everytime I try and set up a form.  Then I spend some much time trying to track down why this error is being caused its not even funny.**

This assingment is to get an understanding of how to get around the access control origin error that can pop up.  By sending a request using the server and not a request from the webpage itself, we are able to pull down json data, in this case, from iTunes.

This is pretty neat to see this in action.  console.log() shows the request being made and what is being returned.